package Day3_09062020;

public class Multiple_conditions {

    public static void main(String[] args) {
        //using multiple conditional statement
        int a = 1;
        int b = 2;
        int c = 4;

        //print if a & b is either equal, greater  or less than c

        if (a+b < c) {
            System.out.println("sum of a & b less than c");
        } else if (a+b > c){
            System.out.println("sum of a & b is grather than c");
        } else {
            System.out.println("sum of a & b is equal to c ");

        }//end of conditional statements


    }//end of main method

}//end of java class
