package Day3_09062020;

public class Methods_Excution_class {
    public static void main(String[] args) {

        Reusable_Methods.add(20, 50);

Reusable_Methods.subtraction(50,20);

//return add method
        int number = Reusable_Methods.returnadd( 40,50);
        System.out.println("My result is " + (number+20));




    }//end of main method
}//end of java class
