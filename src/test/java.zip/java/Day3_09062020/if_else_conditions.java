package Day3_09062020;

public class if_else_conditions {

    public static void main(String[] args) {

       int a = 3;
       int b = 3;

       //single condition using if
        if(a<b) {
            //code goes here
            System.out.println("a is less than b");
        }//end of if condition
        if(a<b) {
            System.out.println("a is less than b");
        } else {
            System.out.println("a is not less than b");

        }//end of if else


        //using if else condition

    }//end of method






}//end of java class
