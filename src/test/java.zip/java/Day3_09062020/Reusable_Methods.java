package Day3_09062020;

public class Reusable_Methods {

    //custom method to add two integer values
    //void methods only excutes the statements inside
    //but doesn't retun anyhing
    public static void  add(int a, int b){
        System.out.println("My result of a & b is " + (a+b));

    }//end of add method

    public static void subtraction(int a, int b){
        System.out.println("My result of a - b is " + (a-b));

    }//end of subtract method

    public static int returnadd(int a, int b) {
        int result = a + b;
        System.out.println("My result of a & b is " + result);
        return result;
    }//end of return add method

}//end of java class
