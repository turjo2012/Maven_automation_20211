package Day1_08302020;

public class Data_type {
    public static void main(String[] args) {
        //define String data
        String message = "welcome 2";
        //define the integer data
        int a = 1000;
        int b = 2000;

        //System.out.println(message);
        //how to combine your variable with a custom message (concetenation)
        System.out.println("a is "+ a +" and my b is " + b +" and the result is " + (a+b));
        // how to add two integer veriable to get a value
        System.out.println(a+b);

    }//end of main method
} //end of java class

