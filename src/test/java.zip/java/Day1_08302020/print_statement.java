package Day1_08302020;

public class print_statement {
}
