package day2_09052020;

public class Linear_Array {
    public static void main(String[] args) {
        //linear string array example
        String[] username = new String[]{"john", "keneth", "milad", "naim", "2"};
        String[] lastname = new String[]{"john", "keneth", "milad", "naim", "2"};

        //print second value from string array
        System.out.println("second user name is "+ username[1] + "last name is " + lastname[1]);

          //Linear integer array exmple
        int[] numbers = new int[] {1,100,300,500};

    }//end of psvm

   }//end of java class

